
To compile and run:

    $ mkdir build
    $ cd build
    $ cmake ..
    $ make
    $ ./hw02 myfile.city.json





