
# geo1004.2023

Starting code for assignments